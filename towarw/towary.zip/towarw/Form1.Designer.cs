﻿namespace towarw
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.CountUD = new System.Windows.Forms.NumericUpDown();
            this.PricePU = new System.Windows.Forms.NumericUpDown();
            this.tbAmount = new System.Windows.Forms.TextBox();
            this.Prod = new System.Windows.Forms.ComboBox();
            this.Paid = new System.Windows.Forms.CheckBox();
            this.Delivered = new System.Windows.Forms.CheckBox();
            this.Sent = new System.Windows.Forms.CheckBox();
            this.Date = new System.Windows.Forms.DateTimePicker();
            this.Desc = new System.Windows.Forms.TextBox();
            this.BPay = new System.Windows.Forms.Button();
            this.BSent = new System.Windows.Forms.Button();
            this.BDelivered = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.plikToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nowyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.otwórzToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.zapiszToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.zapiszjakoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.drukujToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.podglądwydrukuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.zakończToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edytujToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cofnijToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ponówToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.wytnijToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kopiujToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.wklejToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.zaznaczwszystkoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.narzędziaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dostosujToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.opcjeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pomocToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.zawartośćToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.indeksToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.wyszukajToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.informacjeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonLOAD = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSAVE = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.CountUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PricePU)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nazwa:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "ilość szutk:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cena:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Wartość:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Producent:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Opłacone:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Wysłane:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 292);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Data wysyłki:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 328);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Dostarczone";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(490, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Opis";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(99, 78);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 10;
            // 
            // CountUD
            // 
            this.CountUD.Location = new System.Drawing.Point(99, 104);
            this.CountUD.Name = "CountUD";
            this.CountUD.Size = new System.Drawing.Size(120, 20);
            this.CountUD.TabIndex = 11;
            // 
            // PricePU
            // 
            this.PricePU.Location = new System.Drawing.Point(99, 130);
            this.PricePU.Name = "PricePU";
            this.PricePU.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.PricePU.Size = new System.Drawing.Size(120, 20);
            this.PricePU.TabIndex = 12;
            // 
            // tbAmount
            // 
            this.tbAmount.Location = new System.Drawing.Point(99, 161);
            this.tbAmount.Name = "tbAmount";
            this.tbAmount.ReadOnly = true;
            this.tbAmount.Size = new System.Drawing.Size(100, 20);
            this.tbAmount.TabIndex = 13;
            // 
            // Prod
            // 
            this.Prod.FormattingEnabled = true;
            this.Prod.Location = new System.Drawing.Point(94, 195);
            this.Prod.Name = "Prod";
            this.Prod.Size = new System.Drawing.Size(121, 21);
            this.Prod.TabIndex = 14;
            // 
            // Paid
            // 
            this.Paid.AutoSize = true;
            this.Paid.Location = new System.Drawing.Point(94, 230);
            this.Paid.Name = "Paid";
            this.Paid.Size = new System.Drawing.Size(15, 14);
            this.Paid.TabIndex = 15;
            this.Paid.UseVisualStyleBackColor = true;
            // 
            // Delivered
            // 
            this.Delivered.AutoSize = true;
            this.Delivered.Location = new System.Drawing.Point(119, 328);
            this.Delivered.Name = "Delivered";
            this.Delivered.Size = new System.Drawing.Size(15, 14);
            this.Delivered.TabIndex = 16;
            this.Delivered.UseVisualStyleBackColor = true;
            // 
            // Sent
            // 
            this.Sent.AutoSize = true;
            this.Sent.Location = new System.Drawing.Point(94, 259);
            this.Sent.Name = "Sent";
            this.Sent.Size = new System.Drawing.Size(15, 14);
            this.Sent.TabIndex = 17;
            this.Sent.UseVisualStyleBackColor = true;
            // 
            // Date
            // 
            this.Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Date.Location = new System.Drawing.Point(106, 292);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(78, 20);
            this.Date.TabIndex = 18;
            // 
            // Desc
            // 
            this.Desc.Location = new System.Drawing.Point(493, 66);
            this.Desc.Multiline = true;
            this.Desc.Name = "Desc";
            this.Desc.Size = new System.Drawing.Size(164, 80);
            this.Desc.TabIndex = 19;
            // 
            // BPay
            // 
            this.BPay.Location = new System.Drawing.Point(278, 249);
            this.BPay.Name = "BPay";
            this.BPay.Size = new System.Drawing.Size(75, 23);
            this.BPay.TabIndex = 20;
            this.BPay.Text = "Oplacono";
            this.BPay.UseVisualStyleBackColor = true;
            this.BPay.Click += new System.EventHandler(this.BPay_Click);
            // 
            // BSent
            // 
            this.BSent.Location = new System.Drawing.Point(278, 287);
            this.BSent.Name = "BSent";
            this.BSent.Size = new System.Drawing.Size(75, 23);
            this.BSent.TabIndex = 21;
            this.BSent.Text = "Wyslij";
            this.BSent.UseVisualStyleBackColor = true;
            this.BSent.Click += new System.EventHandler(this.BSent_Click);
            // 
            // BDelivered
            // 
            this.BDelivered.Location = new System.Drawing.Point(278, 323);
            this.BDelivered.Name = "BDelivered";
            this.BDelivered.Size = new System.Drawing.Size(75, 23);
            this.BDelivered.TabIndex = 22;
            this.BDelivered.Text = "Dostarczono";
            this.BDelivered.UseVisualStyleBackColor = true;
            this.BDelivered.Click += new System.EventHandler(this.BDelivered_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(18, 18);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.plikToolStripMenuItem1,
            this.edytujToolStripMenuItem1,
            this.narzędziaToolStripMenuItem1,
            this.pomocToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 25);
            this.menuStrip1.TabIndex = 23;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // plikToolStripMenuItem1
            // 
            this.plikToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nowyToolStripMenuItem1,
            this.otwórzToolStripMenuItem,
            this.toolStripSeparator,
            this.zapiszToolStripMenuItem1,
            this.zapiszjakoToolStripMenuItem1,
            this.toolStripSeparator1,
            this.drukujToolStripMenuItem1,
            this.podglądwydrukuToolStripMenuItem,
            this.toolStripSeparator2,
            this.zakończToolStripMenuItem});
            this.plikToolStripMenuItem1.Name = "plikToolStripMenuItem1";
            this.plikToolStripMenuItem1.Size = new System.Drawing.Size(39, 21);
            this.plikToolStripMenuItem1.Text = "&Plik";
            // 
            // nowyToolStripMenuItem1
            // 
            this.nowyToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("nowyToolStripMenuItem1.Image")));
            this.nowyToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.nowyToolStripMenuItem1.Name = "nowyToolStripMenuItem1";
            this.nowyToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.nowyToolStripMenuItem1.Size = new System.Drawing.Size(198, 24);
            this.nowyToolStripMenuItem1.Text = "&Nowy";
            this.nowyToolStripMenuItem1.Click += new System.EventHandler(this.nowyToolStripMenuItem1_Click);
            // 
            // otwórzToolStripMenuItem
            // 
            this.otwórzToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("otwórzToolStripMenuItem.Image")));
            this.otwórzToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.otwórzToolStripMenuItem.Name = "otwórzToolStripMenuItem";
            this.otwórzToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.otwórzToolStripMenuItem.Size = new System.Drawing.Size(198, 24);
            this.otwórzToolStripMenuItem.Text = "&Otwórz";
            this.otwórzToolStripMenuItem.Click += new System.EventHandler(this.otwórzToolStripMenuItem_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(195, 6);
            // 
            // zapiszToolStripMenuItem1
            // 
            this.zapiszToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("zapiszToolStripMenuItem1.Image")));
            this.zapiszToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.zapiszToolStripMenuItem1.Name = "zapiszToolStripMenuItem1";
            this.zapiszToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.zapiszToolStripMenuItem1.Size = new System.Drawing.Size(198, 24);
            this.zapiszToolStripMenuItem1.Text = "&Zapisz";
            this.zapiszToolStripMenuItem1.Click += new System.EventHandler(this.zapiszToolStripMenuItem1_Click);
            // 
            // zapiszjakoToolStripMenuItem1
            // 
            this.zapiszjakoToolStripMenuItem1.Name = "zapiszjakoToolStripMenuItem1";
            this.zapiszjakoToolStripMenuItem1.Size = new System.Drawing.Size(198, 24);
            this.zapiszjakoToolStripMenuItem1.Text = "&Zapisz jako";
            this.zapiszjakoToolStripMenuItem1.Click += new System.EventHandler(this.zapiszjakoToolStripMenuItem1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(195, 6);
            // 
            // drukujToolStripMenuItem1
            // 
            this.drukujToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("drukujToolStripMenuItem1.Image")));
            this.drukujToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.drukujToolStripMenuItem1.Name = "drukujToolStripMenuItem1";
            this.drukujToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.drukujToolStripMenuItem1.Size = new System.Drawing.Size(198, 24);
            this.drukujToolStripMenuItem1.Text = "&Drukuj";
            // 
            // podglądwydrukuToolStripMenuItem
            // 
            this.podglądwydrukuToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("podglądwydrukuToolStripMenuItem.Image")));
            this.podglądwydrukuToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.podglądwydrukuToolStripMenuItem.Name = "podglądwydrukuToolStripMenuItem";
            this.podglądwydrukuToolStripMenuItem.Size = new System.Drawing.Size(198, 24);
            this.podglądwydrukuToolStripMenuItem.Text = "&Podgląd wydruku";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(195, 6);
            // 
            // zakończToolStripMenuItem
            // 
            this.zakończToolStripMenuItem.Name = "zakończToolStripMenuItem";
            this.zakończToolStripMenuItem.Size = new System.Drawing.Size(198, 24);
            this.zakończToolStripMenuItem.Text = "&Zakończ";
            this.zakończToolStripMenuItem.Click += new System.EventHandler(this.zakończToolStripMenuItem_Click);
            // 
            // edytujToolStripMenuItem1
            // 
            this.edytujToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cofnijToolStripMenuItem1,
            this.ponówToolStripMenuItem,
            this.toolStripSeparator3,
            this.wytnijToolStripMenuItem1,
            this.kopiujToolStripMenuItem1,
            this.wklejToolStripMenuItem1,
            this.toolStripSeparator4,
            this.zaznaczwszystkoToolStripMenuItem1});
            this.edytujToolStripMenuItem1.Name = "edytujToolStripMenuItem1";
            this.edytujToolStripMenuItem1.Size = new System.Drawing.Size(55, 21);
            this.edytujToolStripMenuItem1.Text = "&Edytuj";
            // 
            // cofnijToolStripMenuItem1
            // 
            this.cofnijToolStripMenuItem1.Name = "cofnijToolStripMenuItem1";
            this.cofnijToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.cofnijToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
            this.cofnijToolStripMenuItem1.Text = "&Cofnij";
            // 
            // ponówToolStripMenuItem
            // 
            this.ponówToolStripMenuItem.Name = "ponówToolStripMenuItem";
            this.ponówToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.ponówToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            this.ponówToolStripMenuItem.Text = "&Ponów";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 6);
            // 
            // wytnijToolStripMenuItem1
            // 
            this.wytnijToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("wytnijToolStripMenuItem1.Image")));
            this.wytnijToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.wytnijToolStripMenuItem1.Name = "wytnijToolStripMenuItem1";
            this.wytnijToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.wytnijToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
            this.wytnijToolStripMenuItem1.Text = "Wy&tnij";
            // 
            // kopiujToolStripMenuItem1
            // 
            this.kopiujToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("kopiujToolStripMenuItem1.Image")));
            this.kopiujToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.kopiujToolStripMenuItem1.Name = "kopiujToolStripMenuItem1";
            this.kopiujToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.kopiujToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
            this.kopiujToolStripMenuItem1.Text = "&Kopiuj";
            // 
            // wklejToolStripMenuItem1
            // 
            this.wklejToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("wklejToolStripMenuItem1.Image")));
            this.wklejToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.wklejToolStripMenuItem1.Name = "wklejToolStripMenuItem1";
            this.wklejToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.wklejToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
            this.wklejToolStripMenuItem1.Text = "&Wklej";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 6);
            // 
            // zaznaczwszystkoToolStripMenuItem1
            // 
            this.zaznaczwszystkoToolStripMenuItem1.Name = "zaznaczwszystkoToolStripMenuItem1";
            this.zaznaczwszystkoToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
            this.zaznaczwszystkoToolStripMenuItem1.Text = "&Zaznacz wszystko";
            // 
            // narzędziaToolStripMenuItem1
            // 
            this.narzędziaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dostosujToolStripMenuItem1,
            this.opcjeToolStripMenuItem1});
            this.narzędziaToolStripMenuItem1.Name = "narzędziaToolStripMenuItem1";
            this.narzędziaToolStripMenuItem1.Size = new System.Drawing.Size(79, 21);
            this.narzędziaToolStripMenuItem1.Text = "&Narzędzia";
            // 
            // dostosujToolStripMenuItem1
            // 
            this.dostosujToolStripMenuItem1.Name = "dostosujToolStripMenuItem1";
            this.dostosujToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
            this.dostosujToolStripMenuItem1.Text = "&Dostosuj";
            // 
            // opcjeToolStripMenuItem1
            // 
            this.opcjeToolStripMenuItem1.Name = "opcjeToolStripMenuItem1";
            this.opcjeToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
            this.opcjeToolStripMenuItem1.Text = "&Opcje";
            // 
            // pomocToolStripMenuItem1
            // 
            this.pomocToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zawartośćToolStripMenuItem1,
            this.indeksToolStripMenuItem1,
            this.wyszukajToolStripMenuItem1,
            this.toolStripSeparator5,
            this.informacjeToolStripMenuItem1});
            this.pomocToolStripMenuItem1.Name = "pomocToolStripMenuItem1";
            this.pomocToolStripMenuItem1.Size = new System.Drawing.Size(60, 21);
            this.pomocToolStripMenuItem1.Text = "&Pomoc";
            // 
            // zawartośćToolStripMenuItem1
            // 
            this.zawartośćToolStripMenuItem1.Name = "zawartośćToolStripMenuItem1";
            this.zawartośćToolStripMenuItem1.Size = new System.Drawing.Size(198, 24);
            this.zawartośćToolStripMenuItem1.Text = "&Zawartość";
            // 
            // indeksToolStripMenuItem1
            // 
            this.indeksToolStripMenuItem1.Name = "indeksToolStripMenuItem1";
            this.indeksToolStripMenuItem1.Size = new System.Drawing.Size(198, 24);
            this.indeksToolStripMenuItem1.Text = "&Indeks";
            // 
            // wyszukajToolStripMenuItem1
            // 
            this.wyszukajToolStripMenuItem1.Name = "wyszukajToolStripMenuItem1";
            this.wyszukajToolStripMenuItem1.Size = new System.Drawing.Size(198, 24);
            this.wyszukajToolStripMenuItem1.Text = "&Wyszukaj";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(195, 6);
            // 
            // informacjeToolStripMenuItem1
            // 
            this.informacjeToolStripMenuItem1.Name = "informacjeToolStripMenuItem1";
            this.informacjeToolStripMenuItem1.Size = new System.Drawing.Size(198, 24);
            this.informacjeToolStripMenuItem1.Text = "&Informacje...";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(18, 18);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonSAVE,
            this.toolStripButtonLOAD});
            this.toolStrip1.Location = new System.Drawing.Point(0, 25);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 25);
            this.toolStrip1.TabIndex = 24;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonLOAD
            // 
            this.toolStripButtonLOAD.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonLOAD.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLOAD.Image")));
            this.toolStripButtonLOAD.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLOAD.Name = "toolStripButtonLOAD";
            this.toolStripButtonLOAD.Size = new System.Drawing.Size(68, 22);
            this.toolStripButtonLOAD.Text = "Load CSV";
            this.toolStripButtonLOAD.Click += new System.EventHandler(this.toolStripButtonLOAD_Click);
            // 
            // toolStripButtonSAVE
            // 
            this.toolStripButtonSAVE.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonSAVE.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSAVE.Image")));
            this.toolStripButtonSAVE.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSAVE.Name = "toolStripButtonSAVE";
            this.toolStripButtonSAVE.Size = new System.Drawing.Size(82, 22);
            this.toolStripButtonSAVE.Text = "Save to CSV";
            this.toolStripButtonSAVE.Click += new System.EventHandler(this.toolStripButtonSAVE_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.BDelivered);
            this.Controls.Add(this.BSent);
            this.Controls.Add(this.BPay);
            this.Controls.Add(this.Desc);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.Sent);
            this.Controls.Add(this.Delivered);
            this.Controls.Add(this.Paid);
            this.Controls.Add(this.Prod);
            this.Controls.Add(this.tbAmount);
            this.Controls.Add(this.PricePU);
            this.Controls.Add(this.CountUD);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.CountUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PricePU)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.NumericUpDown CountUD;
        private System.Windows.Forms.NumericUpDown PricePU;
        private System.Windows.Forms.TextBox tbAmount;
        private System.Windows.Forms.ComboBox Prod;
        private System.Windows.Forms.CheckBox Paid;
        private System.Windows.Forms.CheckBox Delivered;
        private System.Windows.Forms.CheckBox Sent;
        private System.Windows.Forms.DateTimePicker Date;
        private System.Windows.Forms.TextBox Desc;
        private System.Windows.Forms.Button BPay;
        private System.Windows.Forms.Button BSent;
        private System.Windows.Forms.Button BDelivered;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem plikToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem nowyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem otwórzToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripMenuItem zapiszToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem zapiszjakoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem drukujToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem podglądwydrukuToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem zakończToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem edytujToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cofnijToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ponówToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem wytnijToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem kopiujToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem wklejToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem zaznaczwszystkoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem narzędziaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dostosujToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem opcjeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pomocToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem zawartośćToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem indeksToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem wyszukajToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem informacjeToolStripMenuItem1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonSAVE;
        private System.Windows.Forms.ToolStripButton toolStripButtonLOAD;
    }
}

